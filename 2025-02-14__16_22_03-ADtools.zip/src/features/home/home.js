import { HomeUI } from "./home.ui.js";

export function initHome(container) {
  return new HomeUI(container);
}
