import { HtmlUI } from "./html.ui.js";

export function initHtmlTemplate(container) {
  return new HtmlUI(container);
}