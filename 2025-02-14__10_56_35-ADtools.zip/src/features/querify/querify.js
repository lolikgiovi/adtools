import { initQuerifyUi } from "./ui/querify.ui.js";

export function initQuerify(container) {
  return new initQuerifyUi(container);
}
