import { UuidUI } from "./uuid.ui.js";

export function initUuidGenerator(container) {
    return new UuidUI(container);
}