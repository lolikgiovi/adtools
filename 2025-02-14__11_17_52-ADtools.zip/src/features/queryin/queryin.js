import { QueryInUI } from "./queryin.ui.js";

export function initQueryInGenerator(container) {
    return new QueryInUI(container);
}