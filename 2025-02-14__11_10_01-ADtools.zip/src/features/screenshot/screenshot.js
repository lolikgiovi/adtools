import { ScreenshotUI } from "./screenshot.ui.js";

export function initScreenshotTemplate(container) {
    return new ScreenshotUI(container);
}